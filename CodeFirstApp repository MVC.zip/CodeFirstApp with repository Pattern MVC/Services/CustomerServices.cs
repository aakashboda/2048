﻿using Models.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class CustomerServices:ICustomerServices
    {
        DataContext _context;
        public CustomerServices()
        {
            _context = new DataContext() ;
        }
        public List<Customer> GetCustomers()
        {
            return _context.Customer.ToList();
        }
    }
}
