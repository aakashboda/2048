﻿namespace Models.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate4 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Customers", "Note4", c => c.Int(nullable: false));
            AddColumn("dbo.Customers", "Note5", c => c.Int(nullable: false));
            AddColumn("dbo.Customers", "Note6", c => c.Int());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Customers", "Note6");
            DropColumn("dbo.Customers", "Note5");
            DropColumn("dbo.Customers", "Note4");
        }
    }
}
